 <!-- <?php
// if(isset($_GET['delete_orders'])){
//     $delete_orders=$_GET['delete_orders'];
//     // echo $delete_category;
//     $delete_query="Delete from `user_orders` where order_id=$delete_orders";
//     $result=mysqli_query($con,$delete_query);
//     if($result){
//         echo"<script>alert('Order has been deleted successfully')</script>";
//         echo"<script>window.open('../admin_area/index.php?all_orders','_self')</script>";
//     }
// }

// Assuming $con is your database connection
 -->

?>-->

