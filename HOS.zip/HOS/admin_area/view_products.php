<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>View products</title>
        <!-- bootstrap css link -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
         <!-- font awesome link -->
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
         integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1c0d4DSE0Ga+ri$auTroPR5aQvXU9xC6qOPnzFeg=="
         crossorigin="anonymous" referrerpolicy="no-referrer">
         <link rel="stylesheet" href="style.css">
<style>
   .primary-heading th {
            background-color: #007bff; /* Same color as navigation bar */
            color: dark; /* Same color as navigation bar */
            padding: 10px;
        }
        .secondary-body td{
            background-color: #6c757d;
            color: white; 

        }

    </style>
</head>
<body>
<h3 class="text-center text-success">All Products</h3>
<table class="table table-bordered mt-5">
    <thead class="primary-heading">
        <tr class="text-center">
            <th>Product ID</th>
            <th>Product Title</th>
            <th>Product Price</th>
            <th>Total Sold</th>
            <th>Status</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>

    </thead>
    <tbody class="secondary-body">
        <?php
        $get_products="Select * from `products`";
        $result=mysqli_query($con,$get_products);
        $number=0;
        while($row=mysqli_fetch_assoc($result)){
            $product_id=$row['product_id'];
            $product_title=$row['product_title'];
            $product_price=$row['product_price'];
            $status=$row['status'];
            $number++;
            ?>
            <tr class='text-center'>
            <td><?php echo $number ?></td>
            <td><?php echo $product_title ?></td>
            <td><?php echo $product_price ?></td>
            <td><?php
            $get_count="Select * from `orders_pending` where product_id='$product_id' "; 
            $result_count=mysqli_query($con,$get_count);
            if ($result_count === false) {
                die("Query failed: " . mysqli_error($con));
            }
            if(mysqli_num_rows($result_count) > 0) {
                // Fetch the number of rows
                $rows_count = mysqli_num_rows($result_count);
                echo $rows_count;
            } else {
                echo "Data not set";
            }
            // $rows_count=mysqli_num_rows($result_count);
            
            ?></td>
            <td><?php echo $status ?></td>
            <td><a href='index.php?edit_products=<?php echo $product_id?>'class='text-light'><i class='fa-solid fa-pen-to-square'></i></a></td>
            <td><a href='index.php?delete_product=<?php echo $product_id?>' class='text-danger'><i class='fa-solid fa-trash'></i></a></td>
        </tr>
        <?php
        }
        ?>
        
    </tbody>
</table>
<!-- bootstrap js link -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>
